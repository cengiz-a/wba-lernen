function getMore() {
    'use strict';
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            document.getElementById("contents").innerHTML = xhttp.responseText;
        }
    };
    
    xhttp.open("POST", "testfile.txt", true);
    xhttp.send();
}